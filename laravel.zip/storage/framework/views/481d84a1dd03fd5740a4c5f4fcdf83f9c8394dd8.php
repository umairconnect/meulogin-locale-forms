</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/footer.blade.php ENDPATH**/ ?>