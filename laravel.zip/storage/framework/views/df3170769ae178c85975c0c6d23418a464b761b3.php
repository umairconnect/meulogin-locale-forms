<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
  
        <link rel="stylesheet" href="css/custom.css" type="text/css" />       
        <link rel="stylesheet" href="css/animation.css" type="text/css" />        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">


     

       
    </head>
    <body class="antialiased">
       <div class="navbar-container">
        <nav class="navbar navbar-expand-lg navbar-light" data-sticky="top" style="top: 0px;">
            <div class="container-fluid">
                <a class="navbar-brand logo_text navbar-brand-dynamic-color fade-page" href="#"
                    style="color: #b80cc2; margin-left: 20px; font-size: 40px;">
                    <img src="images/logo_cdsol.png" width="190" alt="">
                </a>
                <div class="collapse navbar-collapse order-3 order-lg-2 justify-content-lg-end" id="navigation-menu">
                    <ul class="navbar-nav my-3 my-lg-0">

                        <li class="nav-item nav_text">
                            <div class="">
                                <a href="/bepartner" class="nav-link nav-item"
                                    role="button"> <?php echo e(__('form_content.tech_partner')); ?></a>
                                    
                            </div>
                        </li>


                       <li class="nav-item nav_text">
                            <div class="">
                                <a href="/technical-partner" class="nav-link nav-item"
                                    role="button"> <?php echo e(__('form_content.tech_partner')); ?></a>
                                    
                            </div>
                        </li>

                        <li class="nav-item nav_text">
                            <div class="">
                                <a href="/contact" class="nav-link nav-item"
                                    role="button"> <?php echo e(__('form_content.contact')); ?></a>
                                    
                            </div>
                        </li>

                        <li class="nav-item nav_text">
                            <div class="">
                                <a href="/support" class="nav-link nav-item"
                                    role="button"> <?php echo e(__('form_content.support')); ?></a>
                                    
                            </div>
                        </li>

<!-- 
                        <li class="nav-item nav_text">
                            <div class="">
                                <a aria-expanded="false" aria-haspopup="true" href="#" class="nav-link nav-item"
                                    role="button"> Planos</a>
                            </div>
                        </li> -->
                        <li class="nav-item nav_text">
                            <div class="">
                                <a aria-expanded="false" aria-haspopup="true" href="#" class="nav-link nav-item"
                                    role="button"> Login</a>
                            </div>
                        </li>
                        <!-- <li class="nav-item nav_text">
                            <div class="">
                                <a aria-expanded="false" aria-haspopup="true" href="#" class="nav-link nav-item"
                                    role="button">Contato</a>
                            </div>
                        </li> -->
                        <div class="d-flex align-items-center order-lg-3">
                            <a href="#" class="nav_btn ml-lg-4 mr-3 mr-md-4 mr-lg-0 d-none d-sm-block order-lg-3">Ativar
                                Agora</a>
                        </div>
                    </ul>
                </div>
            </div>
        </nav>
    </div><?php /**PATH C:\xampp\htdocs\laravel\resources\views/header.blade.php ENDPATH**/ ?>