
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<div class="container">
  <h1>Support</h1>
  <hr>
  <div class="row">

     <div class="col-lg-6">
          <form action="supportdata" method="post">
            <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="name">Groupname/GroupID:</label>
                <input type="text" class="form-control" name="groupname" id="groupname">
              </div>

          

              <div class="form-group">
                <label for="Company">Company:</label>
                <input type="text" class="form-control" name="company">
              </div>

              <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" name="name" />
              </div>

              <div class="form-group">
                <label for="Mobile">Mobile:</label>
                <input type="number" class="form-control" name="mobile"></textarea>
              </div>

              <div class="form-group">
                <label for="assist">For which App or Service you need assistance:</label>
                <select class="form-select" name="assist">
                    <option selected default>Choose</option>
                    <option>Desktop Messenger </option>
                    <option>Client Recover Bot </option>
                    <option>Birthday Bot</option>
                    <option>QRCode </option>
                    <option>Link for Bio </option>
                    <option>Auto Responders</option>
                    <option>Social WIFI</option>
                    <option>Surveys </option>
                    <option>Contact Form </option>
                </select>
              </div>


              <div class="form-group">
                <button type="submit" class="btn mybtn btn-default">Submit</button>
              </div>

              

              
          </form>
     </div>

     <div class="col-lg-6">
         <img src="images/contant.svg" width="50%" />
      </div>

  </div>
   
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\xampp\htdocs\laravel\resources\views/support.blade.php ENDPATH**/ ?>