<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<div class="container">
  <h1>Be A Partner</h1>
  <hr>
  <div class="row">

     <div class="col-lg-6">
          <form action="bepartner" method="post">
            <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" name="name" id="email">
              </div>

              <div class="form-group">
                <label for="type">Type:</label>
                <select class="form-select" name="type">
                  <option selected default>Choose</option>
                  <option>Freelance</option>
                    <option>Independent or Company</option>
                </select>
              </div>

              <div class="form-group">
                <label for="Mobile">Mobile:</label>
                <input type="tel" class="form-control" name="mobile">
              </div>

              <div class="form-group">
                <label for="Mobile">City:</label>
                <input type="text" class="form-control" name="city">
              </div>

              <div class="form-group">
                <input hidden type="text" class="form-control" value="Be a Partner" name="partnertype">
              </div>

              
              <div class="form-group">
                <label for="Mobile">Description:</label>
                <textarea class="form-control" name="description"></textarea>
              </div>

              <div class="form-group">
                <button type="submit" class="btn btn-default">Submit</button>
              </div>

              

              
          </form>
     </div>

     <div class="col-lg-6">
         <img src="images/be-partner.jpeg" width="100%" />
      </div>

  </div>
   
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\xampp\htdocs\laravel\resources\views/beapartner.blade.php ENDPATH**/ ?>