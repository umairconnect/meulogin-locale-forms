$(document).ready(function() {
    $(".box1").mouseenter(function() {
        $(".box_button1").css("display", "initial");
        $(".box_img1").css("width", "80%");
    });
    $(".box1").mouseleave(function() {
        $(".box_button1").css("display", "none");
        $(".box_img1").css("width", "100%");
    });
    $(".box2").mouseenter(function() {
        $(".box_button2").css("display", "initial");
    });
    $(".box2").mouseleave(function() {
        $(".box_button2").css("display", "none");
    });
    $(".box3").mouseenter(function() {
        $(".box_button3").css("display", "initial");
    });
    $(".box3").mouseleave(function() {
        $(".box_button3").css("display", "none");
    });
    $(".box4").mouseenter(function() {
        $(".box_button4").css("display", "initial");
    });
    $(".box4").mouseleave(function() {
        $(".box_button4").css("display", "none");
    });
    $(".box5").mouseenter(function() {
        $(".box_button5").css("display", "initial");
    });
    $(".box5").mouseleave(function() {
        $(".box_button5").css("display", "none");
    });
    $(".box6").mouseenter(function() {
        $(".box_button6").css("display", "initial");
    });
    $(".box6").mouseleave(function() {
        $(".box_button6").css("display", "none");
    });
    $(".box7").mouseenter(function() {
        $(".box_button7").css("display", "initial");
    });
    $(".box7").mouseleave(function() {
        $(".box_button7").css("display", "none");
    });
    $(".box8").mouseenter(function() {
        $(".box_button8").css("display", "initial");
    });
    $(".box8").mouseleave(function() {
        $(".box_button8").css("display", "none");
    });
    $(".box9").mouseenter(function() {
        $(".box_button9").css("display", "initial");
    });
    $(".box9").mouseleave(function() {
        $(".box_button9").css("display", "none");
    });
});