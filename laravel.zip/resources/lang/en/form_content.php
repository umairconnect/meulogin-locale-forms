<?php

return [
    'mainheading' => 'The most practical and easiest',
    'mainheading_two' => 'For registration, research and dissemination of your Business',
     //form data
    'be_partner' => 'Be A Partner',
    'tech_partner' => 'Tecnical Partners',
    'support' => 'Support',
    'contact' => 'Contact',
];