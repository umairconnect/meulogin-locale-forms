<?php
return [
    'mainheading' => 'A mais prática e fácil caixa de soluções',
    'mainheading_two' => 'para cadastro, pesquisa e divulgação do seu Negócio',
    //form data
    'be_partner' => 'Parcerias de Marketing',
    'tech_partner' => 'Parceirias Técnicas',
    'support' => 'Suporte',
    'contact' => 'Contato',
];