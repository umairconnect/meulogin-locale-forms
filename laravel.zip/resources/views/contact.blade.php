
@include('header');

<div class="container">
  <h1>Contact Us</h1>
  <hr>
  <div class="row">

     <div class="col-lg-6">
          <form action="contactdata" method="post">
            @csrf
              <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" name="name" id="email">
              </div>

          

              <div class="form-group">
                <label for="Mobile">Mobile:</label>
                <input type="tel" class="form-control" name="mobile">
              </div>

              <div class="form-group">
                <label for="comment">Comment:</label>
                <textarea class="form-control" name="comments"></textarea>
              </div>

              <div class="form-group">
                <button type="submit" class="btn mybtn btn-default">Submit</button>
              </div>

              

              
          </form>
     </div>

     <div class="col-lg-6">
         <img src="images/contant.svg" width="50%" />
      </div>

  </div>
   
</div>

@include('footer');