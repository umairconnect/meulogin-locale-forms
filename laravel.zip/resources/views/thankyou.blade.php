@include('header');
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h2>You data has been submit. Thank you</h2>
        </div>
    </div>
</div>
@include('footer');