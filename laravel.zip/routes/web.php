<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Beapartner;
use App\Http\Controllers\Contactform;
use App\Http\Controllers\Supportdata;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/thankyou', function () {
    return view('thankyou');
});

Route::view('/contact', 'contact');
Route::post('/contactdata',[Contactform::class, 'addContact']);

Route::view('/support', 'support');
Route::post('/supportdata',[Supportdata::class, 'addSupport']);

Route::view('/bepartner', 'beapartner');
Route::post('/bepartner',[Beapartner::class, 'addPartner']);

Route::view('/technical-partner', 'techpartner');
Route::post('/technicalpartner',[Beapartner::class, 'addTechnical']);



